

require 'osx/cocoa'

class Controller < OSX::NSObject
	
	ib_outlets :text
	
	def initialize
	end
	
	def visible(sender)
		`defaults write com.apple.finder AppleShowAllFiles TRUE`
		`killall Finder`
		@text.setStringValue("Invisible files are visible")
	end
	
	def invisible(sender)
		`defaults write com.apple.finder AppleShowAllFiles FALSE`
		`killall Finder`
		@text.setStringValue("Invisible files are invisible.")
	end

end
